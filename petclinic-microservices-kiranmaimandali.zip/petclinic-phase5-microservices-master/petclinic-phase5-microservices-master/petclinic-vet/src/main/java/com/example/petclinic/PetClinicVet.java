package com.example.petclinic;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PetClinicVet {

    public static void main(String[] args) {

        SpringApplication.run(PetClinicVet.class, args);
    }
}
