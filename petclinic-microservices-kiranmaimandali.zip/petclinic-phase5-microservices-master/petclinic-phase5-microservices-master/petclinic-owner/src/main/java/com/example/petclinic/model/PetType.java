package com.example.petclinic.model;

public enum PetType {

    BIRD, CAT, DOG, HAMPSTER, LIZARD, MONKEY, LOBSTER, ELEPHANT, PIG, HORSE, SNAKE

}
