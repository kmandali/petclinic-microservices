package com.example.petclinic.business;

public class PetClinicBusinessWorkFlowVisit {
}
