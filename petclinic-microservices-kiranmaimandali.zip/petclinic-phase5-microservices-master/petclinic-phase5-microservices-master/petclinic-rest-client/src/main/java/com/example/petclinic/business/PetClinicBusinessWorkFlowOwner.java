package com.example.petclinic.business;

import com.example.petclinic.model.Owner;
import com.example.petclinic.service.OwnerService;

public class PetClinicBusinessWorkFlowOwner {

    OwnerService ownerService;

    public PetClinicBusinessWorkFlowOwner(OwnerService ownerService)

        public void runBusiness () {

        //TODO add business stuff here

            //Create Owners
            Owner owner1 = Owner().withName("Homer Simpson").withAddress("742 Evergreen Terrace").withCity("Springfield").withPhoneNumber("9395550113").build();
            Owner owner2 = Owner().withName("Marge Simpson").withAddress("742 Evergreen Terrace").withCity("Springfield").withPhoneNumber("9395550113").build();
            Owner owner3 = Owner().withName("Bart Simpson").withAddress("742 Evergreen Terrace").withCity("Springfield").withPhoneNumber("9395550113").build();
            Owner owner4 = Owner().withName("Lisa Simpson").withAddress("742 Evergreen Terrace").withCity("Springfield").withPhoneNumber("9395550113").build();


        }
}
